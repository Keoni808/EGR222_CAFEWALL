package src;
//Created by KEONI MORTENSEN on 1/30/2019


import java.awt.*;

public class CafeWall {
    //Setting up background canvas.
    private static final DrawingPanel canvas = new DrawingPanel (650,420);
    private static final Graphics g = canvas.getGraphics();
    //Mortar set above main for easy access
    private static final int mortar = 2;

    public static void main(String[] args) {
        //Setting up GRAY background
        g.setColor(Color.GRAY);
        g.fillRect(0,0,650,420);
        row(0,0,3,24);
        row(40,80,4,36);
        grid(20,140,5,20,0);
        grid(250,180,3,24,16);
        grid(425,200,5,20,16);
        grid(450,20,2,32,32);


    }
    //Method for a single row.
    //(pass in location (x,y), the number of pairs, and the SIZE of box.)
    private static void row (int x, int y, int pairs, int SIZE){
        for (int i = 0; i < pairs; i++) {

            //Creating a black box
            g.setColor(Color.BLACK);
            g.fillRect(x, y, SIZE, SIZE);

            //Creating blue diamond inside box
            g.setColor(Color.BLUE);
            g.drawLine(x + (SIZE / 2), y, x, y + (SIZE / 2));
            g.drawLine(x, y + (SIZE / 2), x + (SIZE / 2), SIZE + y);
            g.drawLine(x + (SIZE / 2), SIZE + y, SIZE + x, y + (SIZE / 2));
            g.drawLine(SIZE + x, y + (SIZE / 2), x + (SIZE / 2), y);

            //Moving the next box location to the right
            x += SIZE;

            //Creating a white box
            g.setColor(Color.WHITE);
            g.fillRect(x, y, SIZE, SIZE);

            //Moving the next box location to the right
            x += SIZE;
        }

    }

    //Method to create stackable rows with an offset.
    //(pass in location (x,y), number of pairs, the size, and the offset)
    private static void grid(int x, int y, int numPairs, int SIZE, int offSet){

        //Creates one stacked pair of row.
        for (int i = 0; i < numPairs; i++) {
            row(x, y, numPairs, SIZE);
            y += SIZE + mortar;
            x += offSet;
            row(x, y, numPairs, SIZE);
            y += SIZE + mortar;
            x -= offSet;
        }

    }


}